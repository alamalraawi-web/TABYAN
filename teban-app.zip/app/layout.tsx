import { ThemeProvider } from "@/components/theme-provider";
import { TibyanShell } from "@/components/tibyan-shell";
import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "تيبان - النظام الصحي الذكي",
  description: "منصة طبية متكاملة مدعومة بالذكاء الاصطناعي",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body>
        <ThemeProvider>
          <TibyanShell>{children}</TibyanShell>
        </ThemeProvider>
      </body>
    </html>
  );
}